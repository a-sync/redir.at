-- phpMyAdmin SQL Dump
-- version 2.9.1.1-Debian-9
-- http://www.phpmyadmin.net
-- 
-- Hoszt: localhost
-- Létrehozás ideje: 2009. Jan 15. 15:57
-- Szerver verzió: 5.0.32
-- PHP Verzió: 5.2.0-8+etch13
-- 
-- Adatbázis: `onethreestudio`
-- 

-- --------------------------------------------------------

-- 
-- Tábla szerkezet: `redir_links`
-- 

CREATE TABLE `redir_links` (
  `liid` int(10) unsigned NOT NULL auto_increment,
  `nicename` tinytext NOT NULL,
  `url` text NOT NULL,
  `owner` tinytext NOT NULL,
  `used` int(10) unsigned NOT NULL default '0',
  `limit` int(10) unsigned NOT NULL default '0',
  `type` int(2) unsigned NOT NULL default '2',
  `secret` tinytext NOT NULL,
  `lastuse` int(10) unsigned NOT NULL default '0',
  `date` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`liid`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=5 ;

-- 
-- Tábla adatok: `redir_links`
-- 

INSERT INTO `redir_links` (`liid`, `nicename`, `url`, `owner`, `used`, `limit`, `type`, `secret`, `lastuse`, `date`) VALUES 
(1, 'webdesign', 'http://www.onethreestudio.com', '', 0, 0, 1, '', 0, 1230768000),
(2, 'redir', 'http://redir.at', '', 0, 0, 1, '', 0, 1230768000),
(3, '000', 'http://www.onethreestudio.com', '', 0, 0, 2, '', 0, 1230768000),

-- --------------------------------------------------------

-- 
-- Tábla szerkezet: `redir_options`
-- 

CREATE TABLE `redir_options` (
  `opid` tinytext NOT NULL,
  `type` int(2) unsigned NOT NULL,
  `text` tinytext NOT NULL,
  `num` int(10) unsigned NOT NULL,
  PRIMARY KEY  (`opid`(250))
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- 
-- Tábla adatok: `redir_options`
-- 

INSERT INTO `redir_options` (`opid`, `type`, `text`, `num`) VALUES 
('next_shortlink', 0, '', 1),
('anon_redir_num', 0, '', 0),
('short_redir_num', 0, '', 0),
('nice_redir_num', 0, '', 0);
